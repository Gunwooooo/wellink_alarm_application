package com.project.schedulerapplication.beans;

/**
 * Created by topgu on 2016-05-14.
 */
public class Schedules {

    public String code;
    public String date;
    public String title;
    public String contents;

}
