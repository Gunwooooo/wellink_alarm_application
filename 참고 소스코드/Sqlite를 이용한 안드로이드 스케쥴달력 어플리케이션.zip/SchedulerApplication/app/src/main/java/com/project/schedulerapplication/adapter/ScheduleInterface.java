package com.project.schedulerapplication.adapter;

/**
 * Created by topgu on 2016-05-15.
 */
public interface ScheduleInterface {
    void deleteScheduleClicked(int position);
}
